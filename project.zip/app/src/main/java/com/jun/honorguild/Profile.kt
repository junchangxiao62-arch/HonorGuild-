package com.jun.honorguild

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.firestore.AggregateSource
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

private fun pdb() = FirebaseFirestore.getInstance()

data class HgBanner(val name: String, val a: Color, val b: Color)

val ProfileBanners = listOf(
    HgBanner("Vampire", Color(0xFFE11D48), Color(0xFF3B0A2A)),
    HgBanner("Neon", Color(0xFF8B5CF6), Color(0xFF22D3EE)),
    HgBanner("Ember", Color(0xFFF59E0B), Color(0xFFEF4444)),
    HgBanner("Ocean", Color(0xFF0EA5E9), Color(0xFF312E81)),
    HgBanner("Forest", Color(0xFF10B981), Color(0xFF064E3B)),
    HgBanner("Midnight", Color(0xFF312E81), Color(0xFF0B0711))
)

val ProfileStyles = listOf("hero" to "Hero", "neon" to "Neon card", "minimal" to "Minimal")

/** Profile data comes from other users' documents, so unknown values fall back to defaults. */
fun safeStyle(s: String?): String = if (ProfileStyles.any { it.first == s }) s!! else "hero"
fun safeBanner(i: Long?): Int = (i ?: 0L).toInt().coerceIn(0, ProfileBanners.size - 1)

data class ProfileData(
    val name: String,
    val bio: String,
    val game: String,
    val status: String,
    val online: Boolean,
    val style: String,
    val banner: Int,
    val stats: List<Pair<String, String>>
)

suspend fun postCount(uid: String): Long = try {
    pdb().collection("posts").whereEqualTo("authorUid", uid).count().get(AggregateSource.SERVER).await().count
} catch (e: Exception) {
    0L
}

// ---------- the profile card in three styles ----------

@Composable
fun ProfileCard(p: ProfileData, modifier: Modifier = Modifier) {
    val b = ProfileBanners[p.banner.coerceIn(0, ProfileBanners.size - 1)]
    val dot = when {
        !p.online -> Color(0xFF6B7280)
        p.status == "busy" -> Color(0xFFEF4444)
        else -> Color(0xFF22C55E)
    }
    val statusText = when {
        !p.online -> "Offline"
        p.status == "busy" -> "Busy"
        else -> "Online"
    }
    when (p.style) {
        "neon" -> NeonProfile(p, b, dot, statusText, modifier)
        "minimal" -> MinimalProfile(p, b, dot, statusText, modifier)
        else -> HeroProfile(p, b, dot, statusText, modifier)
    }
}

@Composable
private fun HeroProfile(p: ProfileData, b: HgBanner, dot: Color, statusText: String, modifier: Modifier) {
    val shape = RoundedCornerShape(22.dp)
    val brand = Brush.linearGradient(listOf(b.a, b.b))
    Column(
        modifier.fillMaxWidth().clip(shape)
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, brand, shape)
    ) {
        Box(Modifier.fillMaxWidth()) {
            Box(Modifier.fillMaxWidth().height(110.dp).background(brand))
            Box(
                Modifier.padding(start = 16.dp, top = 66.dp).size(92.dp)
                    .background(MaterialTheme.colorScheme.surface, CircleShape)
                    .padding(4.dp)
            ) { Avatar(p.name, size = 84.dp, dot = dot) }
        }
        Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 16.dp)) {
            Text("@${p.name}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).background(dot, CircleShape))
                Spacer(Modifier.width(6.dp))
                Text(statusText, style = MaterialTheme.typography.bodySmall, color = dot)
                if (p.game.isNotBlank()) {
                    Text(
                        "   🎮 ${p.game}", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.secondary, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }
            if (p.bio.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(p.bio)
            }
            Spacer(Modifier.height(12.dp))
            StatsRow(p.stats)
        }
    }
}

@Composable
private fun NeonProfile(p: ProfileData, b: HgBanner, dot: Color, statusText: String, modifier: Modifier) {
    val shape = RoundedCornerShape(26.dp)
    Column(
        modifier.fillMaxWidth()
            .clip(shape)
            .background(MaterialTheme.colorScheme.surface)
            .border(1.5.dp, Brush.linearGradient(listOf(b.a, b.b)), shape)
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(116.dp)
                .border(3.dp, Brush.sweepGradient(listOf(b.a, b.b, b.a)), CircleShape)
                .padding(7.dp)
        ) { Avatar(p.name, size = 102.dp, dot = dot) }
        Spacer(Modifier.height(10.dp))
        Text("@${p.name}", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            InfoChip(statusText, dot)
            if (p.game.isNotBlank()) InfoChip("🎮 ${p.game}", b.a)
        }
        if (p.bio.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(p.bio, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(14.dp))
        StatsRow(p.stats)
    }
}

@Composable
private fun MinimalProfile(p: ProfileData, b: HgBanner, dot: Color, statusText: String, modifier: Modifier) {
    val shape = RoundedCornerShape(18.dp)
    Row(
        modifier.fillMaxWidth().clip(shape)
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, shape)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(p.name, size = 60.dp, dot = dot)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text("@${p.name}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
                if (p.game.isNotBlank()) "$statusText  ·  🎮 ${p.game}" else statusText,
                style = MaterialTheme.typography.bodySmall, color = dot,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            if (p.bio.isNotBlank()) {
                Text(
                    p.bio, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(
                p.stats.joinToString("  ·  ") { "${it.second} ${it.first}" },
                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary
            )
        }
        Spacer(Modifier.width(10.dp))
        Box(
            Modifier.width(6.dp).height(60.dp)
                .background(Brush.verticalGradient(listOf(b.a, b.b)), RoundedCornerShape(3.dp))
        )
    }
}

@Composable
private fun InfoChip(text: String, color: Color) {
    Box(
        Modifier.clip(RoundedCornerShape(12.dp))
            .background(color.copy(alpha = 0.18f))
            .border(1.dp, color.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) { Text(text, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
}

@Composable
private fun StatsRow(stats: List<Pair<String, String>>) {
    if (stats.isEmpty()) return
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        stats.forEach { (label, value) ->
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

// ---------- editor controls (used in the Me tab) ----------

@Composable
fun ProfileStyleEditor(style: String, banner: Int, onStyle: (String) -> Unit, onBanner: (Int) -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Text("Profile style", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ProfileStyles.forEach { (id, label) -> Pill(label, style == id) { onStyle(id) } }
        }
        Spacer(Modifier.height(14.dp))
        Text("Banner colors", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            ProfileBanners.forEachIndexed { i, bn ->
                Box(
                    Modifier.size(42.dp)
                        .background(Brush.linearGradient(listOf(bn.a, bn.b)), CircleShape)
                        .border(if (i == banner) 3.dp else 0.dp, Color.White, CircleShape)
                        .clickable { onBanner(i) }
                )
            }
        }
    }
}

// ---------- viewing someone's profile ----------

@Composable
fun ProfileScreen(targetUid: String, myUid: String, onBack: () -> Unit, onMessage: (Peer) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    BackHandler(onBack = onBack)
    var data by remember { mutableStateOf<ProfileData?>(null) }
    var err by remember { mutableStateOf<String?>(null) }
    val own = targetUid == myUid

    LaunchedEffect(targetUid) {
        try {
            val d = pdb().collection("users").document(targetUid).get().await()
            val name = (d.getString("username") ?: "user").take(30)
            val status = d.getString("status") ?: "online"
            val last = d.getTimestamp("lastSeen")?.toDate()?.time
            val online = if (own) status != "invisible"
            else last != null && System.currentTimeMillis() - last < 240_000L && status != "invisible"
            val stats = mutableListOf("Posts" to postCount(targetUid).toString())
            if (own) {
                val friends = pdb().collection("users").document(myUid).collection("friends").get().await().size()
                stats.add(0, "Friends" to friends.toString())
                stats.add(1, "Games" to loadSavedGames(ctx).size.toString())
            }
            data = ProfileData(
                name = name,
                bio = (d.getString("bio") ?: "").take(80),
                game = (d.getString("game") ?: "").take(40),
                status = status,
                online = online,
                style = safeStyle(d.getString("pStyle")),
                banner = safeBanner(d.getLong("pBanner")),
                stats = stats
            )
        } catch (e: Exception) {
            err = e.message ?: "Could not load this profile"
        }
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onBack) { Text("<", fontSize = 22.sp) }
                Text("Profile", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(8.dp))
            val d = data
            when {
                d != null -> {
                    ProfileCard(d)
                    if (!own) {
                        Spacer(Modifier.height(16.dp))
                        Button(
                            onClick = {
                                scope.launch {
                                    try {
                                        val peer = loadPeer(targetUid)
                                        if (peer != null) onMessage(peer)
                                        else Toast.makeText(ctx, "That user isn't ready for chats yet", Toast.LENGTH_SHORT).show()
                                    } catch (e: Exception) {
                                        err = e.message
                                    }
                                }
                            },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().height(50.dp)
                        ) { Text("💬 Message", fontWeight = FontWeight.Bold) }
                        Spacer(Modifier.height(8.dp))
                        TextButton(
                            onClick = {
                                scope.launch {
                                    try {
                                        pdb().collection("users").document(myUid).collection("friends").document(targetUid)
                                            .set(mapOf("username" to d.name)).await()
                                        Toast.makeText(ctx, "Added @${d.name} to your friends", Toast.LENGTH_SHORT).show()
                                    } catch (e: Exception) {
                                        err = e.message
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("+ Add friend") }
                    }
                }
                err == null -> Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
            err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        }
    }
}

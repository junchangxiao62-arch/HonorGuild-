package com.jun.honorguild

import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp

data class HgTheme(
    val name: String,
    val bg: Color,
    val surface: Color,
    val primary: Color,
    val secondary: Color
)

val HgThemes = listOf(
    HgTheme("Vampire", Color(0xFF0B0711), Color(0xFF171021), Color(0xFFE11D48), Color(0xFF8B5CF6)),
    HgTheme("Neon", Color(0xFF070B14), Color(0xFF101826), Color(0xFF8B5CF6), Color(0xFF22D3EE)),
    HgTheme("Ember", Color(0xFF0F0A06), Color(0xFF1C130B), Color(0xFFF59E0B), Color(0xFFEF4444))
)

fun hgColors(t: HgTheme) = darkColorScheme(
    primary = t.primary,
    onPrimary = Color.White,
    secondary = t.secondary,
    onSecondary = Color.White,
    background = t.bg,
    onBackground = Color(0xFFF3ECFA),
    surface = t.surface,
    onSurface = Color(0xFFF3ECFA),
    surfaceVariant = lerp(t.surface, Color.White, 0.10f),
    onSurfaceVariant = Color(0xFFE6DDF2),
    primaryContainer = lerp(t.bg, t.primary, 0.35f),
    onPrimaryContainer = Color.White,
    errorContainer = Color(0xFF5C1A24),
    onErrorContainer = Color(0xFFFFDAD9)
)

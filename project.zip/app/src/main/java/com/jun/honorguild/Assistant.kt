package com.jun.honorguild

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.clickable
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.GenerativeBackend
import com.google.firebase.ai.type.content
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Change this if Google retires the model; everything else keeps working. */
const val AI_MODEL = "gemini-3.8-flash"

/** Used automatically when the main model is busy. */
const val AI_FALLBACK_MODEL = "gemini-3.1-flash-lite"

data class AiMsg(val mine: Boolean, val text: String)

@Composable
fun AssistantScreen(onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val scope = rememberCoroutineScope()
    val msgs = remember { mutableStateListOf<AiMsg>() }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    val ctx = LocalContext.current
    val rules = remember {
        val version = try {
            ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "unknown"
        } catch (e: Exception) {
            "unknown"
        }
        buildAssistantRules(version)
    }

    val chat = remember {
        try {
            Firebase.ai(backend = GenerativeBackend.googleAI())
                .generativeModel(modelName = AI_MODEL, systemInstruction = content { text(rules) })
                .startChat()
        } catch (e: Exception) {
            null
        }
    }

    val fallbackChat = remember {
        try {
            Firebase.ai(backend = GenerativeBackend.googleAI())
                .generativeModel(modelName = AI_FALLBACK_MODEL, systemInstruction = content { text(rules) })
                .startChat()
        } catch (e: Exception) {
            null
        }
    }

    LaunchedEffect(msgs.size) {
        if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.lastIndex)
    }

    fun ask() {
        val q = input.trim()
        if (q.isEmpty() || busy) return
        val c = chat
        input = ""
        msgs.add(AiMsg(true, q))
        if (c == null) {
            msgs.add(AiMsg(false, "The assistant isn't set up yet. Turn on Firebase AI Logic in your Firebase project."))
            return
        }
        busy = true
        scope.launch {
            var reply: String? = null
            var lastError: Exception? = null
            var busyError = false
            // try the main model up to 3 times, then the lighter backup model
            for (attempt in 0..2) {
                try {
                    reply = c.sendMessage(q).text
                    break
                } catch (e: Exception) {
                    lastError = e
                    busyError = isBusyError(e)
                    if (!busyError) break
                    delay(2000L * (attempt + 1))
                }
            }
            if (reply == null && busyError && fallbackChat != null) {
                try {
                    reply = fallbackChat.sendMessage(q).text
                } catch (e: Exception) {
                    lastError = e
                    busyError = isBusyError(e)
                }
            }
            val text = reply?.trim()
            msgs.add(
                AiMsg(
                    false,
                    when {
                        !text.isNullOrEmpty() -> text
                        lastError == null -> "I couldn't answer that."
                        busyError -> "The assistant is busy right now (the free plan has limits). Please try again in a minute."
                        else -> "Assistant unavailable: ${lastError.message ?: "unknown error"}"
                    }
                )
            )
            busy = false
        }
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize()) {
            Surface(color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = onBack) { Text("<", fontSize = 22.sp) }
                    Text("🤖", fontSize = 26.sp)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("Game Assistant", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(
                            "Games and HonorGuild help only",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp)) {
                if (msgs.isEmpty()) {
                    Column(
                        Modifier.fillMaxSize().padding(24.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("🎮", fontSize = 48.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Ask me about game settings, sensitivity, loadouts, tips, or how to use HonorGuild.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                LazyColumn(Modifier.fillMaxSize(), state = listState) {
                    items(msgs.size) { i ->
                        val m = msgs[i]
                        val shape = RoundedCornerShape(
                            topStart = 18.dp, topEnd = 18.dp,
                            bottomStart = if (m.mine) 18.dp else 4.dp,
                            bottomEnd = if (m.mine) 4.dp else 18.dp
                        )
                        val bg = if (m.mine) Modifier.background(brandBrush(), shape)
                        else Modifier.background(MaterialTheme.colorScheme.surfaceVariant, shape)
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 3.dp),
                            horizontalArrangement = if (m.mine) Arrangement.End else Arrangement.Start
                        ) {
                            Box(Modifier.widthIn(max = 300.dp).then(bg).padding(horizontal = 12.dp, vertical = 8.dp)) {
                                Text(m.text, color = Color.White)
                            }
                        }
                    }
                    if (busy) {
                        item { Text("Thinking...", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(8.dp)) }
                    }
                }
            }
            Surface(color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = input, onValueChange = { input = it },
                        placeholder = { Text("Ask about a game or the app") },
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier.weight(1f), maxLines = 4
                    )
                    Spacer(Modifier.width(8.dp))
                    Box(
                        Modifier.size(50.dp).background(brandBrush(), CircleShape).clickable { ask() },
                        contentAlignment = Alignment.Center
                    ) { Text("➤", color = Color.White, fontSize = 20.sp) }
                }
            }
        }
    }
}

private fun isBusyError(e: Exception): Boolean {
    val m = (e.message ?: "").lowercase()
    return listOf("overload", "unavailable", "503", "429", "quota", "rate", "traffic", "high demand", "exhausted")
        .any { it in m }
}

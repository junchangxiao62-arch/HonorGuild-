package com.jun.honorguild

import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

val ForumCats = listOf(
    "general" to "General",
    "guides" to "Guides",
    "squads" to "Squads",
    "showcase" to "Showcase",
    "help" to "Help"
)

val ReportReasons = listOf("Spam or ads", "Harassment or hate", "Scam or selling coins/accounts", "Inappropriate content", "Other")

data class PostItem(
    val id: String, val authorUid: String, val authorName: String,
    val title: String, val body: String, val category: String, val created: Long,
    val likes: List<String>, val replies: Long, val hidden: Boolean, val pinned: Boolean
)

data class CommentItem(
    val id: String, val authorUid: String, val authorName: String,
    val body: String, val created: Long, val hidden: Boolean
)

data class ReportItem(
    val id: String, val type: String, val postId: String, val commentId: String,
    val targetUid: String, val targetName: String, val reporterName: String,
    val reason: String, val snippet: String
)

data class ReportTarget(
    val type: String, val postId: String, val commentId: String,
    val targetUid: String, val targetName: String, val snippet: String
)

private fun fdb() = FirebaseFirestore.getInstance()
private var lastPostAt = 0L

private fun catLabel(id: String) = ForumCats.firstOrNull { it.first == id }?.second ?: "General"

private fun stamp(d: DocumentSnapshot, f: String): Long =
    (d.getTimestamp(f, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.seconds ?: 0L) * 1000L

private fun toPost(d: DocumentSnapshot) = PostItem(
    d.id, d.getString("authorUid") ?: "", d.getString("authorName") ?: "user",
    d.getString("title") ?: "", d.getString("body") ?: "", d.getString("category") ?: "general",
    stamp(d, "created"),
    (d.get("likes") as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
    d.getLong("replies") ?: 0L, d.getBoolean("hidden") ?: false, d.getBoolean("pinned") ?: false
)

private fun toComment(d: DocumentSnapshot) = CommentItem(
    d.id, d.getString("authorUid") ?: "", d.getString("authorName") ?: "user",
    d.getString("body") ?: "", stamp(d, "created"), d.getBoolean("hidden") ?: false
)

// ---------- home cards (shown on the Chats tab) ----------

@Composable
fun HomeCards(onForum: () -> Unit) {
    val ctx = LocalContext.current
    Row(
        Modifier.fillMaxWidth().padding(top = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        HomeCard("💬", "Community Forum", "Guides · Squads · Showcases", Modifier.weight(1f)) { onForum() }
        HomeCard("🛍", "Marketplace", "Cosmetics · Premium · Trades", Modifier.weight(1f)) {
            Toast.makeText(ctx, "Marketplace is coming soon", Toast.LENGTH_SHORT).show()
        }
    }
}

@Composable
fun HomeCard(icon: String, title: String, sub: String, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, brandBrush(), RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(14.dp)
    ) {
        Text(icon, fontSize = 28.sp)
        Spacer(Modifier.height(6.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text(
            sub, style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2
        )
    }
}

// ---------- forum root ----------

@Composable
fun ForumScreen(uid: String, myName: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("hg_prefs", Context.MODE_PRIVATE) }
    var rulesOk by remember { mutableStateOf(prefs.getBoolean("forum_rules_ok", false)) }
    var isAdmin by remember { mutableStateOf(false) }
    var banned by remember { mutableStateOf(false) }
    var blocked by remember { mutableStateOf(mapOf<String, String>()) }
    var posts by remember { mutableStateOf(listOf<PostItem>()) }
    var cat by remember { mutableStateOf("all") }
    var openId by remember { mutableStateOf<String?>(null) }
    var showNew by remember { mutableStateOf(false) }
    var showMod by remember { mutableStateOf(false) }
    var showBlocked by remember { mutableStateOf(false) }
    var report by remember { mutableStateOf<ReportTarget?>(null) }
    var err by remember { mutableStateOf<String?>(null) }

    BackHandler {
        if (showMod) {
            showMod = false
        } else if (openId != null) {
            openId = null
        } else {
            onBack()
        }
    }

    LaunchedEffect(uid) {
        try {
            isAdmin = fdb().collection("admins").document(uid).get().await().exists()
        } catch (_: Exception) {
        }
        try {
            banned = fdb().collection("bans").document(uid).get().await().exists()
        } catch (_: Exception) {
        }
    }

    DisposableEffect(uid) {
        val r1 = fdb().collection("users").document(uid).collection("blocked")
            .addSnapshotListener { s, _ ->
                if (s != null) blocked = s.documents.associate { it.id to (it.getString("name") ?: "user") }
            }
        val r2 = fdb().collection("posts").orderBy("created", Query.Direction.DESCENDING).limit(100)
            .addSnapshotListener { s, e ->
                if (e != null) { err = e.message; return@addSnapshotListener }
                if (s != null) posts = s.documents.map { toPost(it) }
            }
        onDispose {
            r1.remove()
            r2.remove()
        }
    }

    fun blockUser(otherUid: String, name: String) {
        scope.launch {
            try {
                fdb().collection("users").document(uid).collection("blocked").document(otherUid)
                    .set(mapOf("name" to name)).await()
                Toast.makeText(ctx, "Blocked @$name", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                err = e.message
            }
        }
    }

    val visible = posts
        .filter { (cat == "all" || it.category == cat) && it.authorUid !in blocked && (!it.hidden || isAdmin) }
        .sortedWith(compareByDescending<PostItem> { it.pinned }.thenByDescending { it.created })
    val open = posts.firstOrNull { it.id == openId }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        when {
            !rulesOk -> RulesGate(
                onAgree = {
                    prefs.edit().putBoolean("forum_rules_ok", true).apply()
                    rulesOk = true
                },
                onBack = onBack
            )
            showMod -> ModerationScreen(uid, onBack = { showMod = false })
            open != null -> PostScreen(
                p = open, uid = uid, myName = myName, isAdmin = isAdmin, banned = banned,
                blocked = blocked.keys,
                onBack = { openId = null },
                onReport = { report = it },
                onBlock = { id, n -> blockUser(id, n); openId = null }
            )
            else -> ForumList(
                posts = visible, cat = cat, onCat = { cat = it }, banned = banned, isAdmin = isAdmin,
                blockedCount = blocked.size, err = err,
                onNew = { showNew = true }, onOpen = { openId = it.id },
                onBack = onBack, onMod = { showMod = true }, onBlocked = { showBlocked = true }
            )
        }
    }

    if (showNew) {
        NewPostDialog(
            uid = uid, myName = myName,
            onDismiss = { showNew = false },
            onPosted = { showNew = false; Toast.makeText(ctx, "Posted", Toast.LENGTH_SHORT).show() }
        )
    }
    report?.let { t ->
        ReportDialog(t, uid, myName) { msg ->
            report = null
            if (msg != null) Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
        }
    }
    if (showBlocked) {
        AlertDialog(
            onDismissRequest = { showBlocked = false },
            title = { Text("Blocked users") },
            text = {
                Column {
                    if (blocked.isEmpty()) Text("You haven't blocked anyone.")
                    blocked.forEach { (id, name) ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("@$name", modifier = Modifier.weight(1f))
                            TextButton(onClick = {
                                scope.launch {
                                    try {
                                        fdb().collection("users").document(uid).collection("blocked").document(id).delete().await()
                                    } catch (e: Exception) {
                                        err = e.message
                                    }
                                }
                            }) { Text("Unblock") }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showBlocked = false }) { Text("Close") } }
        )
    }
}

@Composable
fun RulesGate(onAgree: () -> Unit, onBack: () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(16.dp))
        Text("📜", fontSize = 48.sp)
        Text(
            "Forum rules",
            style = MaterialTheme.typography.headlineMedium.copy(brush = brandBrush(), fontWeight = FontWeight.Bold)
        )
        Spacer(Modifier.height(16.dp))
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    "1. Be respectful. No harassment, hate or threats.",
                    "2. No spam, ads or self-promotion.",
                    "3. No buying or selling accounts, coins or items for real money.",
                    "4. No cheats, hacks or modded game files.",
                    "5. Don't share personal information, yours or anyone else's.",
                    "6. No adult, violent or illegal content.",
                    "7. Posts are public. Reports are reviewed, and rule breakers can be banned."
                ).forEach { Text(it) }
            }
        }
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = onAgree,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) { Text("I agree and continue", fontWeight = FontWeight.Bold) }
        TextButton(onClick = onBack) { Text("Go back") }
    }
}

// ---------- list ----------

@Composable
fun ForumList(
    posts: List<PostItem>, cat: String, onCat: (String) -> Unit, banned: Boolean, isAdmin: Boolean,
    blockedCount: Int, err: String?, onNew: () -> Unit, onOpen: (PostItem) -> Unit,
    onBack: () -> Unit, onMod: () -> Unit, onBlocked: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("<", fontSize = 22.sp) }
            Text(
                "Community Forum",
                style = MaterialTheme.typography.titleLarge.copy(brush = brandBrush(), fontWeight = FontWeight.Bold),
                modifier = Modifier.weight(1f)
            )
            if (isAdmin) TextButton(onClick = onMod) { Text("🛡 Mod") }
        }
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
            item { Pill("All", cat == "all") { onCat("all") } }
            items(ForumCats) { c -> Pill(c.second, cat == c.first) { onCat(c.first) } }
        }
        err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        if (banned) {
            Text(
                "You are banned from posting in the forum.",
                color = MaterialTheme.colorScheme.error,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }
        if (posts.isEmpty()) {
            Column(
                Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("No posts here yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Be the first to post.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(Modifier.weight(1f)) {
                items(posts, key = { it.id }) { p -> PostCard(p) { onOpen(p) } }
            }
        }
        if (blockedCount > 0) {
            TextButton(onClick = onBlocked) { Text("Blocked users ($blockedCount)") }
        }
        Button(
            onClick = onNew,
            enabled = !banned,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) { Text("+ New post", fontWeight = FontWeight.Bold) }
    }
}

@Composable
fun PostCard(p: PostItem, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
            .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(16.dp))
            .clickable { onClick() }
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    catLabel(p.category).uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary,
                    fontWeight = FontWeight.Bold
                )
                if (p.pinned) Text("   📌 Pinned", style = MaterialTheme.typography.labelSmall)
                if (p.hidden) Text("   (hidden)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
            }
            Spacer(Modifier.height(4.dp))
            Text(
                p.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                maxLines = 2, overflow = TextOverflow.Ellipsis
            )
            if (p.body.isNotBlank()) {
                Text(
                    p.body, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2, overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(p.authorName, size = 24.dp)
                Spacer(Modifier.width(8.dp))
                Text(
                    "@${p.authorName} · ${fmtListTime(p.created)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text("👍 ${p.likes.size}   💬 ${p.replies}", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

// ---------- post + comments ----------

@Composable
fun PostScreen(
    p: PostItem, uid: String, myName: String, isAdmin: Boolean, banned: Boolean,
    blocked: Set<String>, onBack: () -> Unit, onReport: (ReportTarget) -> Unit,
    onBlock: (String, String) -> Unit
) {
    val scope = rememberCoroutineScope()
    var comments by remember { mutableStateOf(listOf<CommentItem>()) }
    var input by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val mine = p.authorUid == uid
    val liked = uid in p.likes

    DisposableEffect(p.id) {
        val r = fdb().collection("posts").document(p.id).collection("comments").orderBy("created")
            .addSnapshotListener { s, e ->
                if (e != null) { err = e.message; return@addSnapshotListener }
                if (s != null) comments = s.documents.map { toComment(it) }
            }
        onDispose { r.remove() }
    }

    fun toggleLike() {
        scope.launch {
            try {
                fdb().collection("posts").document(p.id).update(
                    "likes", if (liked) FieldValue.arrayRemove(uid) else FieldValue.arrayUnion(uid)
                ).await()
            } catch (e: Exception) {
                err = e.message
            }
        }
    }

    fun sendComment() {
        val text = input.trim()
        if (text.isEmpty() || banned || busy) return
        busy = true
        scope.launch {
            try {
                val postRef = fdb().collection("posts").document(p.id)
                val cRef = postRef.collection("comments").document()
                val batch = fdb().batch()
                batch.set(
                    cRef,
                    mapOf(
                        "authorUid" to uid, "authorName" to myName, "body" to text.take(500),
                        "created" to FieldValue.serverTimestamp(), "hidden" to false
                    )
                )
                batch.update(postRef, "replies", FieldValue.increment(1))
                batch.commit().await()
                input = ""
            } catch (e: Exception) {
                err = e.message
            }
            busy = false
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("<", fontSize = 22.sp) }
            Text(catLabel(p.category), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
        LazyColumn(Modifier.weight(1f).padding(horizontal = 16.dp)) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Avatar(p.authorName, size = 40.dp)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("@${p.authorName}", fontWeight = FontWeight.Bold)
                        Text(
                            fmtListTime(p.created), style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text(p.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(p.body)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { toggleLike() }) { Text(if (liked) "👍 ${p.likes.size} (liked)" else "👍 ${p.likes.size}") }
                    if (!mine) TextButton(onClick = {
                        onReport(ReportTarget("post", p.id, "", p.authorUid, p.authorName, p.title.take(120)))
                    }) { Text("Report") }
                    if (!mine) TextButton(onClick = { onBlock(p.authorUid, p.authorName) }) { Text("Block") }
                    if (mine || isAdmin) TextButton(onClick = { confirmDelete = true }) { Text("Delete") }
                }
                if (isAdmin) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(onClick = {
                            scope.launch {
                                try { fdb().collection("posts").document(p.id).update("pinned", !p.pinned).await() }
                                catch (e: Exception) { err = e.message }
                            }
                        }) { Text(if (p.pinned) "Unpin" else "Pin") }
                        TextButton(onClick = {
                            scope.launch {
                                try { fdb().collection("posts").document(p.id).update("hidden", !p.hidden).await() }
                                catch (e: Exception) { err = e.message }
                            }
                        }) { Text(if (p.hidden) "Unhide" else "Hide") }
                    }
                }
                err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                HorizontalDivider(Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                Text("Comments (${p.replies})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
            }
            items(comments.filter { it.authorUid !in blocked && (!it.hidden || isAdmin) }, key = { it.id }) { c ->
                Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Avatar(c.authorName, size = 28.dp)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "@${c.authorName} · ${fmtListTime(c.created)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (c.hidden) Text("  (hidden)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    }
                    Text(c.body, modifier = Modifier.padding(start = 36.dp, top = 2.dp))
                    Row(Modifier.padding(start = 28.dp)) {
                        if (c.authorUid != uid) {
                            Text(
                                "Report", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.clickable {
                                    onReport(ReportTarget("comment", p.id, c.id, c.authorUid, c.authorName, c.body.take(120)))
                                }.padding(8.dp)
                            )
                        }
                        if (c.authorUid == uid || isAdmin) {
                            Text(
                                "Delete", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.clickable {
                                    scope.launch {
                                        try {
                                            fdb().collection("posts").document(p.id).collection("comments").document(c.id).delete().await()
                                        } catch (e: Exception) {
                                            err = e.message
                                        }
                                    }
                                }.padding(8.dp)
                            )
                        }
                    }
                }
            }
        }
        Surface(color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth()) {
            if (banned) {
                Text(
                    "You are banned from commenting.",
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(16.dp)
                )
            } else {
                Row(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = input, onValueChange = { if (it.length <= 500) input = it },
                        placeholder = { Text("Add a comment") },
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier.weight(1f), maxLines = 4
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { sendComment() }, enabled = !busy) { Text("Send") }
                }
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete this post?") },
            text = { Text("This can't be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    scope.launch {
                        try {
                            fdb().collection("posts").document(p.id).delete().await()
                            onBack()
                        } catch (e: Exception) {
                            err = e.message
                        }
                    }
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
        )
    }
}

// ---------- dialogs ----------

@Composable
fun NewPostDialog(uid: String, myName: String, onDismiss: () -> Unit, onPosted: () -> Unit) {
    val scope = rememberCoroutineScope()
    var cat by remember { mutableStateOf("general") }
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New post") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(ForumCats) { c -> Pill(c.second, cat == c.first) { cat = c.first } }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = title, onValueChange = { if (it.length <= 80) title = it },
                    label = { Text("Title") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = body, onValueChange = { if (it.length <= 2000) body = it },
                    label = { Text("What's on your mind?") }, minLines = 4, maxLines = 8,
                    modifier = Modifier.fillMaxWidth()
                )
                err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(enabled = !busy, onClick = {
                val t = title.trim()
                val now = System.currentTimeMillis()
                when {
                    t.length < 3 -> err = "Title needs at least 3 characters"
                    now - lastPostAt < 30_000L -> err = "Please wait a few seconds before posting again"
                    else -> {
                        busy = true
                        err = null
                        scope.launch {
                            try {
                                fdb().collection("posts").add(
                                    mapOf(
                                        "authorUid" to uid, "authorName" to myName, "title" to t,
                                        "body" to body.trim(), "category" to cat,
                                        "created" to FieldValue.serverTimestamp(),
                                        "likes" to emptyList<String>(), "replies" to 0L,
                                        "hidden" to false, "pinned" to false
                                    )
                                ).await()
                                lastPostAt = System.currentTimeMillis()
                                onPosted()
                            } catch (e: Exception) {
                                err = e.message ?: "Could not post"
                            }
                            busy = false
                        }
                    }
                }
            }) { Text("Post") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun ReportDialog(t: ReportTarget, uid: String, myName: String, onDone: (String?) -> Unit) {
    val scope = rememberCoroutineScope()
    var reason by remember { mutableStateOf(ReportReasons[0]) }
    var busy by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = { onDone(null) },
        title = { Text("Report @${t.targetName}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ReportReasons.forEach { r -> Pill(r, reason == r) { reason = r } }
            }
        },
        confirmButton = {
            TextButton(enabled = !busy, onClick = {
                busy = true
                scope.launch {
                    val id = "${t.type}_${t.commentId.ifBlank { t.postId }}_$uid"
                    try {
                        fdb().collection("reports").document(id).set(
                            mapOf(
                                "type" to t.type, "postId" to t.postId, "commentId" to t.commentId,
                                "targetUid" to t.targetUid, "targetName" to t.targetName,
                                "reporterUid" to uid, "reporterName" to myName,
                                "reason" to reason, "snippet" to t.snippet,
                                "created" to FieldValue.serverTimestamp()
                            )
                        ).await()
                        onDone("Report sent. Thank you.")
                    } catch (e: Exception) {
                        onDone("You already reported this, or it couldn't be sent.")
                    }
                }
            }) { Text("Send report") }
        },
        dismissButton = { TextButton(onClick = { onDone(null) }) { Text("Cancel") } }
    )
}

// ---------- moderation (admins only) ----------

@Composable
fun ModerationScreen(uid: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var reports by remember { mutableStateOf(listOf<ReportItem>()) }
    var err by remember { mutableStateOf<String?>(null) }

    DisposableEffect(uid) {
        val r = fdb().collection("reports").orderBy("created", Query.Direction.DESCENDING).limit(50)
            .addSnapshotListener { s, e ->
                if (e != null) { err = e.message; return@addSnapshotListener }
                if (s != null) {
                    reports = s.documents.map {
                        ReportItem(
                            it.id, it.getString("type") ?: "post", it.getString("postId") ?: "",
                            it.getString("commentId") ?: "", it.getString("targetUid") ?: "",
                            it.getString("targetName") ?: "user", it.getString("reporterName") ?: "user",
                            it.getString("reason") ?: "", it.getString("snippet") ?: ""
                        )
                    }
                }
            }
        onDispose { r.remove() }
    }

    fun contentRef(r: ReportItem) =
        if (r.commentId.isBlank()) fdb().collection("posts").document(r.postId)
        else fdb().collection("posts").document(r.postId).collection("comments").document(r.commentId)

    fun act(r: ReportItem, what: String) {
        scope.launch {
            try {
                when (what) {
                    "hide" -> contentRef(r).update("hidden", true).await()
                    "delete" -> contentRef(r).delete().await()
                    "ban" -> {
                        fdb().collection("bans").document(r.targetUid).set(
                            mapOf("reason" to r.reason, "by" to uid, "created" to FieldValue.serverTimestamp())
                        ).await()
                        try { contentRef(r).update("hidden", true).await() } catch (_: Exception) {}
                    }
                }
                fdb().collection("reports").document(r.id).delete().await()
                Toast.makeText(ctx, "Done", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                err = e.message
            }
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("<", fontSize = 22.sp) }
            Text("🛡 Reports", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        if (reports.isEmpty()) {
            Text("No open reports.", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(16.dp))
        }
        LazyColumn {
            items(reports, key = { it.id }) { r ->
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text(
                            "${r.type.uppercase()} by @${r.targetName}",
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Reported by @${r.reporterName}: ${r.reason}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        if (r.snippet.isNotBlank()) {
                            Text("\"${r.snippet}\"", modifier = Modifier.padding(vertical = 6.dp))
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                            TextButton(onClick = { act(r, "hide") }) { Text("Hide") }
                            TextButton(onClick = { act(r, "delete") }) { Text("Delete") }
                            TextButton(onClick = { act(r, "ban") }) { Text("Ban user") }
                            TextButton(onClick = { act(r, "dismiss") }) { Text("Dismiss") }
                        }
                    }
                }
            }
        }
    }
}

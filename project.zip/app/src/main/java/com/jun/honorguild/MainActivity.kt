package com.jun.honorguild

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import javax.crypto.spec.SecretKeySpec

data class Peer(val uid: String, val name: String, val pub: String)
data class ChatItem(val id: String, val peerUid: String, val peerName: String, val updated: Long)
data class Msg(val id: String, val mine: Boolean, val text: String)

private fun db() = FirebaseFirestore.getInstance()
private fun fa() = FirebaseAuth.getInstance()

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

// ---------- data helpers ----------

suspend fun loadPeer(uid: String): Peer? {
    val d = db().collection("users").document(uid).get().await()
    val pub = d.getString("publicKey") ?: return null
    return Peer(uid, d.getString("username") ?: "user", pub)
}

suspend fun findPeer(name: String, myUid: String): Peer {
    val n = name.trim().lowercase()
    val u = db().collection("usernames").document(n).get().await().getString("uid")
        ?: error("No user with that username")
    if (u == myUid) error("That's you")
    return loadPeer(u) ?: error("That user isn't ready yet")
}

suspend fun doLogin(email: String, pass: String): String? = try {
    fa().signInWithEmailAndPassword(email.trim(), pass).await()
    null
} catch (e: Exception) {
    e.message ?: "Login failed"
}

suspend fun doRegister(ctx: Context, email: String, pass: String, username: String): String? {
    val name = username.trim().lowercase()
    if (!Regex("^[a-z0-9_]{3,20}$").matches(name)) return "Username: 3-20 letters, numbers or _"
    val result = try {
        fa().createUserWithEmailAndPassword(email.trim(), pass).await()
    } catch (e: Exception) {
        return e.message ?: "Could not create account"
    }
    val user = result.user ?: return "Could not create account"
    val uid = user.uid
    return try {
        val pub = Keys.createFor(ctx, uid)
        db().runTransaction { tx ->
            val nameRef = db().collection("usernames").document(name)
            if (tx.get(nameRef).exists()) throw IllegalStateException("Username already taken")
            tx.set(nameRef, mapOf("uid" to uid))
            tx.set(db().collection("users").document(uid), mapOf("username" to name, "publicKey" to pub))
            null
        }.await()
        null
    } catch (e: Exception) {
        Keys.clearFor(ctx, uid)
        try { user.delete().await() } catch (_: Exception) {}
        fa().signOut()
        if (e.message?.contains("already taken") == true) "Username already taken"
        else e.message ?: "Could not finish sign-up"
    }
}

// ---------- screens ----------

@Composable
fun App() {
    val ctx = LocalContext.current
    var uid by remember { mutableStateOf(fa().currentUser?.uid) }
    var myName by remember { mutableStateOf<String?>(null) }
    var peer by remember { mutableStateOf<Peer?>(null) }
    var loadError by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(uid) {
        myName = null
        val u = uid ?: return@LaunchedEffect
        try {
            val doc = db().collection("users").document(u).get().await()
            var local = Keys.myPublic(ctx, u)
            if (local == null) local = Keys.createFor(ctx, u)
            if (doc.getString("publicKey") != local) {
                db().collection("users").document(u)
                    .set(mapOf("publicKey" to local), SetOptions.merge()).await()
            }
            myName = doc.getString("username") ?: ""
        } catch (e: Exception) {
            loadError = e.message ?: "Something went wrong"
        }
    }

    val u = uid
    val n = myName
    val p = peer
    when {
        u == null -> AuthScreen { uid = it }
        loadError != null -> Column(Modifier.fillMaxSize().padding(24.dp)) {
            Text("Error: $loadError")
            Spacer(Modifier.height(12.dp))
            Button(onClick = { fa().signOut(); loadError = null; uid = null }) { Text("Back to login") }
        }
        n == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        p == null -> ChatList(u, n, onOpen = { peer = it }, onLogout = { fa().signOut(); uid = null })
        else -> ChatScreen(u, n, p, onBack = { peer = null })
    }
}

@Composable
fun AuthScreen(onDone: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var register by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var user by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("HonorGuild", style = MaterialTheme.typography.headlineMedium)
        Text("Private one-on-one chat", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(24.dp))
        if (register) {
            OutlinedTextField(
                value = user, onValueChange = { user = it }, singleLine = true,
                label = { Text("Username") }, modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
        }
        OutlinedTextField(
            value = email, onValueChange = { email = it }, singleLine = true,
            label = { Text("Email") }, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = pass, onValueChange = { pass = it }, singleLine = true,
            label = { Text("Password (6+ characters)") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        err?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }
        Spacer(Modifier.height(16.dp))
        Button(
            enabled = !busy,
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                busy = true
                err = null
                scope.launch {
                    err = if (register) doRegister(ctx, email, pass, user) else doLogin(email, pass)
                    busy = false
                    if (err == null) fa().currentUser?.uid?.let(onDone)
                }
            }
        ) { Text(if (register) "Create account" else "Log in") }
        TextButton(onClick = { register = !register; err = null }) {
            Text(if (register) "I already have an account" else "Create a new account")
        }
    }
}

@Composable
fun ChatList(uid: String, myName: String, onOpen: (Peer) -> Unit, onLogout: () -> Unit) {
    val scope = rememberCoroutineScope()
    var chats by remember { mutableStateOf(listOf<ChatItem>()) }
    var showNew by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    DisposableEffect(uid) {
        val reg = db().collection("chats").whereArrayContains("participants", uid)
            .addSnapshotListener { snap, e ->
                if (e != null) { err = e.message; return@addSnapshotListener }
                val list = snap?.documents?.mapNotNull { d ->
                    val parts = d.get("participants") as? List<*> ?: return@mapNotNull null
                    val other = parts.firstOrNull { it != uid } as? String ?: return@mapNotNull null
                    val names = d.get("names") as? Map<*, *>
                    ChatItem(
                        d.id, other, (names?.get(other) as? String) ?: "user",
                        d.getTimestamp("updated")?.seconds ?: 0L
                    )
                }
                if (list != null) chats = list.sortedByDescending { it.updated }
            }
        onDispose { reg.remove() }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("HonorGuild", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
            TextButton(onClick = onLogout) { Text("Log out") }
        }
        Text("Signed in as @$myName", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(12.dp))
        Button(onClick = { newName = ""; err = null; showNew = true }) { Text("New chat") }
        err?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }
        Spacer(Modifier.height(12.dp))
        if (chats.isEmpty()) Text("No chats yet. Tap New chat and enter a friend's username.")
        LazyColumn {
            items(chats, key = { it.id }) { c ->
                Text(
                    "@${c.peerName}",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.fillMaxWidth().clickable {
                        scope.launch {
                            try {
                                loadPeer(c.peerUid)?.let(onOpen)
                            } catch (e: Exception) {
                                err = e.message
                            }
                        }
                    }.padding(vertical = 16.dp)
                )
                HorizontalDivider()
            }
        }
    }

    if (showNew) {
        AlertDialog(
            onDismissRequest = { showNew = false },
            title = { Text("New chat") },
            text = {
                Column {
                    OutlinedTextField(
                        value = newName, onValueChange = { newName = it }, singleLine = true,
                        label = { Text("Their username") }
                    )
                    err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            },
            confirmButton = {
                TextButton(enabled = !busy, onClick = {
                    busy = true
                    err = null
                    scope.launch {
                        try {
                            val p = findPeer(newName, uid)
                            showNew = false
                            onOpen(p)
                        } catch (e: Exception) {
                            err = e.message
                        }
                        busy = false
                    }
                }) { Text("Start") }
            },
            dismissButton = { TextButton(onClick = { showNew = false }) { Text("Cancel") } }
        )
    }
}

@Composable
fun ChatScreen(uid: String, myName: String, peerIn: Peer, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    BackHandler(onBack = onBack)

    var peer by remember { mutableStateOf(peerIn) }
    var key by remember { mutableStateOf<SecretKeySpec?>(null) }
    var keyChanged by remember { mutableStateOf(false) }
    var raw by remember { mutableStateOf(listOf<Triple<String, String, String>>()) }
    var input by remember { mutableStateOf("") }
    var showCode by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }
    val chatId = remember { listOf(uid, peerIn.uid).sorted().joinToString("_") }
    val listState = rememberLazyListState()

    LaunchedEffect(peerIn.uid) {
        try {
            val fresh = loadPeer(peerIn.uid) ?: peerIn
            peer = fresh
            val pinned = Keys.pinned(ctx, uid, fresh.uid)
            if (pinned == null) Keys.pin(ctx, uid, fresh.uid, fresh.pub)
            keyChanged = pinned != null && pinned != fresh.pub
            val myPriv = Keys.myPrivate(ctx, uid) ?: error("Missing your key on this phone")
            key = Crypto.sharedKey(Crypto.privateFrom(myPriv), Crypto.publicFrom(fresh.pub))
        } catch (e: Exception) {
            err = e.message ?: "Could not set up encryption"
        }
    }

    DisposableEffect(chatId) {
        val reg = db().collection("chats").document(chatId).collection("messages").orderBy("t")
            .addSnapshotListener { snap, e ->
                if (e != null) { err = e.message; return@addSnapshotListener }
                if (snap != null) {
                    raw = snap.documents.map {
                        Triple(it.id, it.getString("sender") ?: "", it.getString("ct") ?: "")
                    }
                }
            }
        onDispose { reg.remove() }
    }

    val shown = remember(raw, key) {
        raw.map { (id, sender, ct) ->
            val k = key
            val text = if (k == null) "..." else try {
                Crypto.decrypt(k, ct)
            } catch (e: Exception) {
                "Can't decrypt this message"
            }
            Msg(id, sender == uid, text)
        }
    }

    LaunchedEffect(shown.size) {
        if (shown.isNotEmpty()) listState.animateScrollToItem(shown.lastIndex)
    }

    fun send() {
        val k = key ?: return
        val text = input.trim()
        if (text.isEmpty() || keyChanged) return
        input = ""
        scope.launch {
            try {
                val chatRef = db().collection("chats").document(chatId)
                chatRef.set(
                    mapOf(
                        "participants" to listOf(uid, peer.uid).sorted(),
                        "names" to mapOf(uid to myName, peer.uid to peer.name),
                        "updated" to FieldValue.serverTimestamp()
                    ),
                    SetOptions.merge()
                ).await()
                chatRef.collection("messages").add(
                    mapOf(
                        "sender" to uid,
                        "ct" to Crypto.encrypt(k, text),
                        "t" to FieldValue.serverTimestamp()
                    )
                ).await()
            } catch (e: Exception) {
                err = e.message ?: "Could not send"
            }
        }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 8.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("<") }
            Text("@${peer.name}", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            TextButton(onClick = { showCode = true }) { Text("Verify") }
        }
        Text("End-to-end encrypted", style = MaterialTheme.typography.bodySmall)
        if (keyChanged) {
            Spacer(Modifier.height(6.dp))
            Column(
                Modifier.fillMaxWidth()
                    .background(MaterialTheme.colorScheme.errorContainer, RoundedCornerShape(8.dp))
                    .padding(10.dp)
            ) {
                Text(
                    "Warning: this contact's security key changed. They may have reinstalled the app, " +
                        "or someone is tampering. Compare the Verify code with them before trusting it.",
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
                TextButton(onClick = {
                    Keys.pin(ctx, uid, peer.uid, peer.pub)
                    keyChanged = false
                }) { Text("Trust new key") }
            }
        }
        err?.let {
            Spacer(Modifier.height(6.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }
        Spacer(Modifier.height(6.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState) {
            items(shown, key = { it.id }) { m ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 3.dp),
                    horizontalArrangement = if (m.mine) Arrangement.End else Arrangement.Start
                ) {
                    Box(
                        Modifier.widthIn(max = 280.dp)
                            .background(
                                if (m.mine) MaterialTheme.colorScheme.primaryContainer
                                else MaterialTheme.colorScheme.surfaceVariant,
                                RoundedCornerShape(12.dp)
                            )
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) { Text(m.text) }
                }
            }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it },
                placeholder = { Text("Message") },
                modifier = Modifier.weight(1f), maxLines = 4
            )
            Spacer(Modifier.padding(horizontal = 4.dp))
            Button(onClick = { send() }, enabled = key != null && !keyChanged) { Text("Send") }
        }
    }

    if (showCode) {
        val mine = Keys.myPublic(ctx, uid) ?: ""
        AlertDialog(
            onDismissRequest = { showCode = false },
            title = { Text("Security code") },
            text = {
                Column {
                    Text(Crypto.safetyNumber(mine, peer.pub), style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Text("Ask @${peer.name} to open this screen on their phone. If both codes match exactly, nobody is intercepting your chat.")
                }
            },
            confirmButton = { TextButton(onClick = { showCode = false }) { Text("Close") } }
        )
    }
}

package com.jun.honorguild

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import javax.crypto.spec.SecretKeySpec

data class Peer(val uid: String, val name: String, val pub: String)
data class ChatItem(val id: String, val peerUid: String, val peerName: String, val updated: Long)
data class Friend(val uid: String, val name: String, val online: Boolean)
data class RawMsg(val id: String, val sender: String, val ct: String, val time: Long)
data class Msg(val id: String, val mine: Boolean, val text: String, val time: Long)

private fun db() = FirebaseFirestore.getInstance()
private fun fa() = FirebaseAuth.getInstance()

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

// ---------- data helpers ----------

suspend fun loadPeer(uid: String): Peer? {
    val d = db().collection("users").document(uid).get().await()
    val pub = d.getString("publicKey") ?: return null
    return Peer(uid, d.getString("username") ?: "user", pub)
}

suspend fun findPeer(name: String, myUid: String): Peer {
    val n = name.trim().lowercase()
    val u = db().collection("usernames").document(n).get().await().getString("uid")
        ?: error("No user with that username")
    if (u == myUid) error("That's you")
    return loadPeer(u) ?: error("That user isn't ready yet")
}

suspend fun loadFriends(uid: String): List<Friend> {
    val snap = db().collection("users").document(uid).collection("friends").get().await()
    val now = System.currentTimeMillis()
    return snap.documents.map { d ->
        var name = d.getString("username") ?: "user"
        var online = false
        try {
            val ud = db().collection("users").document(d.id).get().await()
            ud.getString("username")?.let { name = it }
            val last = ud.getTimestamp("lastSeen")?.toDate()?.time
            online = last != null && now - last < 150_000L
        } catch (_: Exception) {
        }
        Friend(d.id, name, online)
    }.sortedWith(compareByDescending<Friend> { it.online }.thenBy { it.name })
}

suspend fun doLogin(email: String, pass: String): String? = try {
    fa().signInWithEmailAndPassword(email.trim(), pass).await()
    null
} catch (e: Exception) {
    e.message ?: "Login failed"
}

suspend fun doRegister(ctx: Context, email: String, pass: String, username: String): String? {
    val name = username.trim().lowercase()
    if (!Regex("^[a-z0-9_]{3,20}$").matches(name)) return "Username: 3-20 letters, numbers or _"
    val result = try {
        fa().createUserWithEmailAndPassword(email.trim(), pass).await()
    } catch (e: Exception) {
        return e.message ?: "Could not create account"
    }
    val user = result.user ?: return "Could not create account"
    val uid = user.uid
    return try {
        val pub = Keys.createFor(ctx, uid)
        db().runTransaction { tx ->
            val nameRef = db().collection("usernames").document(name)
            if (tx.get(nameRef).exists()) throw IllegalStateException("Username already taken")
            tx.set(nameRef, mapOf("uid" to uid))
            tx.set(db().collection("users").document(uid), mapOf("username" to name, "publicKey" to pub))
            null
        }.await()
        null
    } catch (e: Exception) {
        Keys.clearFor(ctx, uid)
        try { user.delete().await() } catch (_: Exception) {}
        fa().signOut()
        if (e.message?.contains("already taken") == true) "Username already taken"
        else e.message ?: "Could not finish sign-up"
    }
}

// ---------- root ----------

@Composable
fun App() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("hg_prefs", Context.MODE_PRIVATE) }
    var themeIdx by remember {
        mutableStateOf(prefs.getInt("theme", 0).coerceIn(0, HgThemes.size - 1))
    }
    MaterialTheme(colorScheme = hgColors(HgThemes[themeIdx])) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Root(themeIdx) { i ->
                themeIdx = i
                prefs.edit().putInt("theme", i).apply()
            }
        }
    }
}

@Composable
fun Root(themeIdx: Int, onTheme: (Int) -> Unit) {
    val ctx = LocalContext.current
    var uid by remember { mutableStateOf(fa().currentUser?.uid) }
    var myName by remember { mutableStateOf<String?>(null) }
    var peer by remember { mutableStateOf<Peer?>(null) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableStateOf(0) }

    LaunchedEffect(uid) {
        myName = null
        val u = uid ?: return@LaunchedEffect
        try {
            val doc = db().collection("users").document(u).get().await()
            var local = Keys.myPublic(ctx, u)
            if (local == null) local = Keys.createFor(ctx, u)
            if (doc.getString("publicKey") != local) {
                db().collection("users").document(u)
                    .set(mapOf("publicKey" to local), SetOptions.merge()).await()
            }
            myName = doc.getString("username") ?: ""
        } catch (e: Exception) {
            loadError = e.message ?: "Something went wrong"
        }
    }

    // "online" heartbeat so friends can see you are active
    LaunchedEffect(uid, myName) {
        val u = uid ?: return@LaunchedEffect
        if (myName == null) return@LaunchedEffect
        while (true) {
            try {
                db().collection("users").document(u)
                    .set(mapOf("lastSeen" to FieldValue.serverTimestamp()), SetOptions.merge()).await()
            } catch (_: Exception) {
            }
            delay(60_000L)
        }
    }

    val u = uid
    val n = myName
    val p = peer
    when {
        u == null -> AuthScreen { uid = it }
        loadError != null -> Column(Modifier.fillMaxSize().padding(24.dp)) {
            Text("Error: $loadError")
            Spacer(Modifier.height(12.dp))
            Button(onClick = { fa().signOut(); loadError = null; uid = null }) { Text("Back to login") }
        }
        n == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        p != null -> ChatScreen(u, n, p, onBack = { peer = null })
        else -> Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> ChatsTab(u, onOpen = { peer = it })
                    1 -> FriendsTab(u, onOpen = { peer = it })
                    2 -> CallsTab()
                    else -> MeTab(n, themeIdx, onTheme, onLogout = {
                        fa().signOut(); uid = null; tab = 0
                    })
                }
            }
            NavigationBar {
                listOf("💬" to "Chats", "👥" to "Friends", "📞" to "Calls", "⚙" to "Me")
                    .forEachIndexed { i, (icon, label) ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Text(icon, fontSize = 20.sp) },
                            label = { Text(label) }
                        )
                    }
            }
        }
    }
}

// ---------- login ----------

@Composable
fun AuthScreen(onDone: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var register by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var user by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Logo(120.dp)
        Spacer(Modifier.height(16.dp))
        Text(
            "HonorGuild",
            style = MaterialTheme.typography.displaySmall.copy(brush = brandBrush(), fontWeight = FontWeight.Bold)
        )
        Text(
            "Private. Encrypted. Yours.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(24.dp))
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(16.dp)) {
                if (register) {
                    OutlinedTextField(
                        value = user, onValueChange = { user = it }, singleLine = true,
                        label = { Text("Username") }, modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                }
                OutlinedTextField(
                    value = email, onValueChange = { email = it }, singleLine = true,
                    label = { Text("Email") }, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = pass, onValueChange = { pass = it }, singleLine = true,
                    label = { Text("Password (6+ characters)") },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                err?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(it, color = MaterialTheme.colorScheme.error)
                }
                Spacer(Modifier.height(16.dp))
                Button(
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    onClick = {
                        busy = true
                        err = null
                        scope.launch {
                            err = if (register) doRegister(ctx, email, pass, user) else doLogin(email, pass)
                            busy = false
                            if (err == null) fa().currentUser?.uid?.let(onDone)
                        }
                    }
                ) { Text(if (register) "Create account" else "Log in", fontWeight = FontWeight.Bold) }
                TextButton(
                    onClick = { register = !register; err = null },
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                ) {
                    Text(if (register) "I already have an account" else "Create a new account")
                }
            }
        }
    }
}

// ---------- chats tab ----------

@Composable
fun ChatsTab(uid: String, onOpen: (Peer) -> Unit) {
    val scope = rememberCoroutineScope()
    var chats by remember { mutableStateOf(listOf<ChatItem>()) }
    var showNew by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    DisposableEffect(uid) {
        val reg = db().collection("chats").whereArrayContains("participants", uid)
            .addSnapshotListener { snap, e ->
                if (e != null) { err = e.message; return@addSnapshotListener }
                val list = snap?.documents?.mapNotNull { d ->
                    val parts = d.get("participants") as? List<*> ?: return@mapNotNull null
                    val other = parts.firstOrNull { it != uid } as? String ?: return@mapNotNull null
                    val names = d.get("names") as? Map<*, *>
                    val ts = d.getTimestamp("updated", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    ChatItem(
                        d.id, other, (names?.get(other) as? String) ?: "user",
                        (ts?.seconds ?: 0L) * 1000L
                    )
                }
                if (list != null) chats = list.sortedByDescending { it.updated }
            }
        onDispose { reg.remove() }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Logo(40.dp)
            Spacer(Modifier.width(10.dp))
            Text(
                "Chats",
                style = MaterialTheme.typography.headlineSmall.copy(brush = brandBrush(), fontWeight = FontWeight.Bold),
                modifier = Modifier.weight(1f)
            )
            Button(onClick = { newName = ""; err = null; showNew = true }, shape = RoundedCornerShape(12.dp)) {
                Text("+ New chat")
            }
        }
        err?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }
        Spacer(Modifier.height(12.dp))
        if (chats.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "No chats yet.\nTap \"New chat\" and enter a friend's username.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        LazyColumn {
            items(chats, key = { it.id }) { c ->
                Row(
                    Modifier.fillMaxWidth()
                        .clickable {
                            scope.launch {
                                try {
                                    loadPeer(c.peerUid)?.let(onOpen)
                                } catch (e: Exception) {
                                    err = e.message
                                }
                            }
                        }
                        .padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(c.peerName)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("@${c.peerName}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(
                            "Encrypted chat",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        fmtListTime(c.updated),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
            }
        }
    }

    if (showNew) {
        AlertDialog(
            onDismissRequest = { showNew = false },
            title = { Text("New chat") },
            text = {
                Column {
                    OutlinedTextField(
                        value = newName, onValueChange = { newName = it }, singleLine = true,
                        label = { Text("Their username") }
                    )
                    err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            },
            confirmButton = {
                TextButton(enabled = !busy, onClick = {
                    busy = true
                    err = null
                    scope.launch {
                        try {
                            val p = findPeer(newName, uid)
                            showNew = false
                            onOpen(p)
                        } catch (e: Exception) {
                            err = e.message
                        }
                        busy = false
                    }
                }) { Text("Start") }
            },
            dismissButton = { TextButton(onClick = { showNew = false }) { Text("Cancel") } }
        )
    }
}

// ---------- friends tab ----------

@Composable
fun FriendsTab(uid: String, onOpen: (Peer) -> Unit) {
    val scope = rememberCoroutineScope()
    var friends by remember { mutableStateOf(listOf<Friend>()) }
    var tick by remember { mutableStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var addName by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    LaunchedEffect(uid, tick) {
        while (true) {
            try {
                friends = loadFriends(uid)
            } catch (e: Exception) {
                err = e.message
            }
            delay(30_000L)
        }
    }

    val online = friends.filter { it.online }
    val offline = friends.filter { !it.online }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Friends",
                style = MaterialTheme.typography.headlineSmall.copy(brush = brandBrush(), fontWeight = FontWeight.Bold),
                modifier = Modifier.weight(1f)
            )
            Button(onClick = { addName = ""; err = null; showAdd = true }, shape = RoundedCornerShape(12.dp)) {
                Text("+ Add friend")
            }
        }
        Spacer(Modifier.height(8.dp))
        if (friends.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "No friends yet.\nTap \"Add friend\" and enter their username.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        LazyColumn {
            if (online.isNotEmpty()) {
                item { SectionLabel("ONLINE - ${online.size}") }
                items(online, key = { "on_" + it.uid }) { f ->
                    FriendRow(f, onOpen = {
                        scope.launch {
                            try { loadPeer(f.uid)?.let(onOpen) } catch (e: Exception) { err = e.message }
                        }
                    }, onRemove = {
                        scope.launch {
                            try {
                                db().collection("users").document(uid).collection("friends").document(f.uid).delete().await()
                                tick++
                            } catch (e: Exception) { err = e.message }
                        }
                    })
                }
            }
            if (offline.isNotEmpty()) {
                item { SectionLabel("OFFLINE - ${offline.size}") }
                items(offline, key = { "off_" + it.uid }) { f ->
                    FriendRow(f, onOpen = {
                        scope.launch {
                            try { loadPeer(f.uid)?.let(onOpen) } catch (e: Exception) { err = e.message }
                        }
                    }, onRemove = {
                        scope.launch {
                            try {
                                db().collection("users").document(uid).collection("friends").document(f.uid).delete().await()
                                tick++
                            } catch (e: Exception) { err = e.message }
                        }
                    })
                }
            }
        }
    }

    if (showAdd) {
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Add friend") },
            text = {
                Column {
                    OutlinedTextField(
                        value = addName, onValueChange = { addName = it }, singleLine = true,
                        label = { Text("Their username") }
                    )
                    err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            },
            confirmButton = {
                TextButton(enabled = !busy, onClick = {
                    busy = true
                    err = null
                    scope.launch {
                        try {
                            val p = findPeer(addName, uid)
                            db().collection("users").document(uid).collection("friends").document(p.uid)
                                .set(mapOf("username" to p.name)).await()
                            showAdd = false
                            tick++
                        } catch (e: Exception) {
                            err = e.message
                        }
                        busy = false
                    }
                }) { Text("Add") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Cancel") } }
        )
    }
}

@Composable
fun SectionLabel(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.secondary,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
    )
}

@Composable
fun FriendRow(f: Friend, onOpen: () -> Unit, onRemove: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onOpen() }.padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(f.name, online = f.online)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("@${f.name}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
                if (f.online) "Online" else "Offline",
                style = MaterialTheme.typography.bodySmall,
                color = if (f.online) Color(0xFF22C55E) else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        TextButton(onClick = onRemove) { Text("Remove") }
    }
}

// ---------- calls + me ----------

@Composable
fun CallsTab() {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("📞", fontSize = 56.sp)
        Spacer(Modifier.height(12.dp))
        Text("Calls are coming soon", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Voice calls first, then group calls with up to 5 people.",
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun MeTab(name: String, themeIdx: Int, onTheme: (Int) -> Unit, onLogout: () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(12.dp))
        Avatar(name, size = 96.dp)
        Spacer(Modifier.height(12.dp))
        Text("@$name", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(28.dp))
        Text("Theme", style = MaterialTheme.typography.titleMedium, modifier = Modifier.align(Alignment.Start))
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            HgThemes.forEachIndexed { i, t ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.clickable { onTheme(i) }
                ) {
                    Box(
                        Modifier.size(60.dp)
                            .background(Brush.linearGradient(listOf(t.primary, t.secondary)), CircleShape)
                            .border(if (i == themeIdx) 3.dp else 0.dp, Color.White, CircleShape)
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(t.name, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        Spacer(Modifier.height(28.dp))
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                "🔐 Your messages are end-to-end encrypted. Your private key stays on this phone, " +
                    "so the server can't read your chats.",
                modifier = Modifier.padding(16.dp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.height(24.dp))
        Button(
            onClick = onLogout,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) { Text("Log out") }
    }
}

// ---------- chat screen ----------

@Composable
fun ChatScreen(uid: String, myName: String, peerIn: Peer, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    BackHandler(onBack = onBack)

    var peer by remember { mutableStateOf(peerIn) }
    var key by remember { mutableStateOf<SecretKeySpec?>(null) }
    var keyChanged by remember { mutableStateOf(false) }
    var raw by remember { mutableStateOf(listOf<RawMsg>()) }
    var input by remember { mutableStateOf("") }
    var showCode by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }
    val chatId = remember { listOf(uid, peerIn.uid).sorted().joinToString("_") }
    val listState = rememberLazyListState()

    LaunchedEffect(peerIn.uid) {
        try {
            val fresh = loadPeer(peerIn.uid) ?: peerIn
            peer = fresh
            val pinned = Keys.pinned(ctx, uid, fresh.uid)
            if (pinned == null) Keys.pin(ctx, uid, fresh.uid, fresh.pub)
            keyChanged = pinned != null && pinned != fresh.pub
            val myPriv = Keys.myPrivate(ctx, uid) ?: error("Missing your key on this phone")
            key = Crypto.sharedKey(Crypto.privateFrom(myPriv), Crypto.publicFrom(fresh.pub))
        } catch (e: Exception) {
            err = e.message ?: "Could not set up encryption"
        }
    }

    DisposableEffect(chatId) {
        val reg = db().collection("chats").document(chatId).collection("messages").orderBy("t")
            .addSnapshotListener { snap, e ->
                if (e != null) { err = e.message; return@addSnapshotListener }
                if (snap != null) {
                    raw = snap.documents.map {
                        val ts = it.getTimestamp("t", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        RawMsg(
                            it.id, it.getString("sender") ?: "", it.getString("ct") ?: "",
                            (ts?.seconds ?: 0L) * 1000L
                        )
                    }
                }
            }
        onDispose { reg.remove() }
    }

    val shown = remember(raw, key) {
        raw.map { m ->
            val k = key
            val text = if (k == null) "..." else try {
                Crypto.decrypt(k, m.ct)
            } catch (e: Exception) {
                "Can't decrypt this message"
            }
            Msg(m.id, m.sender == uid, text, m.time)
        }
    }

    LaunchedEffect(shown.size) {
        if (shown.isNotEmpty()) listState.animateScrollToItem(shown.lastIndex)
    }

    fun send() {
        val k = key ?: return
        val text = input.trim()
        if (text.isEmpty() || keyChanged) return
        input = ""
        scope.launch {
            try {
                val chatRef = db().collection("chats").document(chatId)
                chatRef.set(
                    mapOf(
                        "participants" to listOf(uid, peer.uid).sorted(),
                        "names" to mapOf(uid to myName, peer.uid to peer.name),
                        "updated" to FieldValue.serverTimestamp()
                    ),
                    SetOptions.merge()
                ).await()
                chatRef.collection("messages").add(
                    mapOf(
                        "sender" to uid,
                        "ct" to Crypto.encrypt(k, text),
                        "t" to FieldValue.serverTimestamp()
                    )
                ).await()
            } catch (e: Exception) {
                err = e.message ?: "Could not send"
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        // top bar
        Surface(color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onBack) { Text("<", fontSize = 22.sp) }
                Avatar(peer.name, size = 40.dp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("@${peer.name}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "🔐 End-to-end encrypted",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                TextButton(onClick = { showCode = true }) { Text("Verify") }
            }
        }

        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            if (keyChanged) {
                Spacer(Modifier.height(6.dp))
                Column(
                    Modifier.fillMaxWidth()
                        .background(MaterialTheme.colorScheme.errorContainer, RoundedCornerShape(10.dp))
                        .padding(10.dp)
                ) {
                    Text(
                        "Warning: this contact's security key changed. They may have reinstalled the app, " +
                            "or someone is tampering. Compare the Verify code with them before trusting it.",
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                    TextButton(onClick = {
                        Keys.pin(ctx, uid, peer.uid, peer.pub)
                        keyChanged = false
                    }) { Text("Trust new key") }
                }
            }
            err?.let {
                Spacer(Modifier.height(6.dp))
                Text(it, color = MaterialTheme.colorScheme.error)
            }
            Spacer(Modifier.height(6.dp))
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState) {
                items(shown, key = { it.id }) { m ->
                    val shape = RoundedCornerShape(
                        topStart = 18.dp, topEnd = 18.dp,
                        bottomStart = if (m.mine) 18.dp else 4.dp,
                        bottomEnd = if (m.mine) 4.dp else 18.dp
                    )
                    val bg = if (m.mine) Modifier.background(brandBrush(), shape)
                    else Modifier.background(MaterialTheme.colorScheme.surfaceVariant, shape)
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 3.dp),
                        horizontalArrangement = if (m.mine) Arrangement.End else Arrangement.Start
                    ) {
                        Column(
                            Modifier.widthIn(max = 290.dp).then(bg)
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(m.text, color = Color.White)
                            if (m.time > 0L) {
                                Text(
                                    fmtClock(m.time),
                                    fontSize = 10.sp,
                                    color = Color.White.copy(alpha = 0.65f),
                                    modifier = Modifier.align(Alignment.End)
                                )
                            }
                        }
                    }
                }
            }
        }

        // input bar
        Surface(color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input, onValueChange = { input = it },
                    placeholder = { Text("Message") },
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.weight(1f), maxLines = 4
                )
                Spacer(Modifier.width(8.dp))
                Box(
                    Modifier.size(50.dp)
                        .background(if (key != null && !keyChanged) brandBrush() else Brush.linearGradient(listOf(Color.Gray, Color.Gray)), CircleShape)
                        .clickable(enabled = key != null && !keyChanged) { send() },
                    contentAlignment = Alignment.Center
                ) { Text("➤", color = Color.White, fontSize = 20.sp) }
            }
        }
    }

    if (showCode) {
        val mine = Keys.myPublic(ctx, uid) ?: ""
        AlertDialog(
            onDismissRequest = { showCode = false },
            title = { Text("Security code") },
            text = {
                Column {
                    Text(Crypto.safetyNumber(mine, peer.pub), style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Text("Ask @${peer.name} to open this screen on their phone. If both codes match exactly, nobody is intercepting your chat.")
                }
            },
            confirmButton = { TextButton(onClick = { showCode = false }) { Text("Close") } }
        )
    }
}

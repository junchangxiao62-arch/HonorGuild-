package com.jun.honorguild

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import org.json.JSONObject
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.AudioSource
import org.webrtc.AudioTrack
import org.webrtc.audio.JavaAudioDeviceModule

data class IncomingCall(val id: String, val hostName: String, val members: List<String>, val names: Map<String, String>)
data class ActiveCall(val id: String, val members: List<String>, val names: Map<String, String>)

open class Sdp : SdpObserver {
    override fun onCreateSuccess(p0: SessionDescription?) {}
    override fun onSetSuccess() {}
    override fun onCreateFailure(p0: String?) {}
    override fun onSetFailure(p0: String?) {}
}

/**
 * Voice calls over WebRTC. Everyone connects to everyone (mesh), so group calls are
 * capped at 5 people to keep them smooth. WebRTC encrypts the audio, and its audio
 * processing provides noise suppression, echo cancellation and automatic gain control.
 */
object CallManager {
    var active by mutableStateOf<ActiveCall?>(null)
    var joined by mutableStateOf<Set<String>>(emptySet())
    var connected by mutableStateOf<Set<String>>(emptySet())
    var muted by mutableStateOf(false)
    var speaker by mutableStateOf(false)
    var status by mutableStateOf("")
    var incoming by mutableStateOf<IncomingCall?>(null)
    var meUid: String = ""
        private set

    private class Link(val uid: String) {
        var pc: PeerConnection? = null
        val pending = mutableListOf<IceCandidate>()
        var remoteSet = false
        var offered = false
    }

    private lateinit var app: Context
    private var factory: PeerConnectionFactory? = null
    private var audioSource: AudioSource? = null
    private var track: AudioTrack? = null
    private val links = HashMap<String, Link>()
    private val declined = HashSet<String>()
    private var callReg: ListenerRegistration? = null
    private var sigReg: ListenerRegistration? = null
    private var ringJob: Job? = null
    private var sawOthers = false
    private var iceServers: List<PeerConnection.IceServer> = emptyList()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private fun callRef(id: String) = FirebaseFirestore.getInstance().collection("calls").document(id)

    // ----- incoming calls (while the app is open) -----

    fun watchIncoming(uid: String): ListenerRegistration =
        FirebaseFirestore.getInstance().collection("calls").whereArrayContains("members", uid)
            .addSnapshotListener { snap, e ->
                if (e != null || snap == null) return@addSnapshotListener
                val now = System.currentTimeMillis()
                var found: IncomingCall? = null
                for (d in snap.documents) {
                    if (d.id in declined) continue
                    val joinedList = (d.get("joined") as? List<*>) ?: emptyList<Any>()
                    if (joinedList.any { it == uid }) continue
                    val host = d.getString("host") ?: continue
                    if (host == uid) continue
                    val created = d.getTimestamp("created", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        ?.toDate()?.time ?: continue
                    if (now - created > 45_000L) continue
                    val members = (d.get("members") as? List<*>)?.filterIsInstance<String>() ?: continue
                    val names = (d.get("names") as? Map<*, *>)
                        ?.entries?.associate { it.key.toString() to it.value.toString() } ?: emptyMap()
                    found = IncomingCall(d.id, names[host] ?: "someone", members, names)
                    break
                }
                incoming = found
            }

    fun decline(id: String) {
        declined.add(id)
        incoming = null
    }

    // ----- starting and joining -----

    suspend fun start(ctx: Context, myUid: String, myName: String, targets: List<Pair<String, String>>): String? {
        if (active != null) return "You're already in a call"
        if (targets.isEmpty() || targets.size > 4) return "Pick 1 to 4 people (5 total with you)"
        return try {
            val members = listOf(myUid) + targets.map { it.first }
            val names: Map<String, String> = (targets + (myUid to myName)).toMap()
            val ref = FirebaseFirestore.getInstance().collection("calls").document()
            ref.set(
                mapOf(
                    "host" to myUid,
                    "members" to members,
                    "names" to names,
                    "joined" to listOf(myUid),
                    "created" to FieldValue.serverTimestamp()
                )
            ).await()
            begin(ctx, ref.id, myUid, members, names)
            null
        } catch (e: Exception) {
            e.message ?: "Could not start the call"
        }
    }

    fun begin(ctx: Context, callId: String, myUid: String, members: List<String>, names: Map<String, String>) {
        if (active != null) return
        app = ctx.applicationContext
        meUid = myUid
        incoming = null
        sawOthers = false
        active = ActiveCall(callId, members, names)
        joined = setOf(myUid)
        connected = emptySet()
        muted = false
        speaker = false
        status = "Calling..."
        ensureFactory()
        track?.setEnabled(true)
        val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        am.isSpeakerphoneOn = false
        ContextCompat.startForegroundService(app, Intent(app, CallService::class.java))
        scope.launch {
            loadIce()
            attach(callId)
        }
        ringJob = scope.launch {
            delay(45_000L)
            if (!sawOthers && active != null) {
                status = "No answer"
                finish(true)
            }
        }
    }

    // ----- controls -----

    fun toggleMute() {
        muted = !muted
        track?.setEnabled(!muted)
    }

    fun toggleSpeaker() {
        speaker = !speaker
        val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.isSpeakerphoneOn = speaker
    }

    fun hangup() {
        finish(true)
    }

    // ----- internals -----

    private fun ensureFactory() {
        if (factory != null) return
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(app).createInitializationOptions()
        )
        val adm = JavaAudioDeviceModule.builder(app)
            .setUseHardwareAcousticEchoCanceler(true)
            .setUseHardwareNoiseSuppressor(true)
            .createAudioDeviceModule()
        val f = PeerConnectionFactory.builder().setAudioDeviceModule(adm).createPeerConnectionFactory()
        val c = MediaConstraints()
        c.mandatory.add(MediaConstraints.KeyValuePair("googEchoCancellation", "true"))
        c.mandatory.add(MediaConstraints.KeyValuePair("googEchoCancellation2", "true"))
        c.mandatory.add(MediaConstraints.KeyValuePair("googNoiseSuppression", "true"))
        c.mandatory.add(MediaConstraints.KeyValuePair("googNoiseSuppression2", "true"))
        c.mandatory.add(MediaConstraints.KeyValuePair("googHighpassFilter", "true"))
        c.mandatory.add(MediaConstraints.KeyValuePair("googAutoGainControl", "true"))
        factory = f
        audioSource = f.createAudioSource(c)
        track = f.createAudioTrack("hg-audio", audioSource)
    }

    private suspend fun loadIce() {
        val list = mutableListOf(
            PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
            PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer()
        )
        try {
            val d = FirebaseFirestore.getInstance().collection("config").document("turn").get().await()
            val urls = (d.get("urls") as? List<*>)?.filterIsInstance<String>().orEmpty()
            val user = d.getString("username")
            val cred = d.getString("credential")
            if (urls.isNotEmpty() && user != null && cred != null) {
                list.add(PeerConnection.IceServer.builder(urls).setUsername(user).setPassword(cred).createIceServer())
            }
        } catch (_: Exception) {
        }
        iceServers = list
    }

    private fun attach(callId: String) {
        val ref = callRef(callId)
        ref.update("joined", FieldValue.arrayUnion(meUid))
        callReg = ref.addSnapshotListener { snap, e ->
            if (e != null) return@addSnapshotListener
            if (snap == null || !snap.exists()) {
                if (active != null) finish(false)
                return@addSnapshotListener
            }
            val j = (snap.get("joined") as? List<*>)?.filterIsInstance<String>() ?: emptyList()
            joined = j.toSet()
            sync(j)
        }
        sigReg = ref.collection("signals").whereEqualTo("to", meUid)
            .addSnapshotListener { snap, _ ->
                snap?.documentChanges?.forEach { ch ->
                    if (ch.type == DocumentChange.Type.ADDED) handleSignal(ch.document)
                }
            }
    }

    private fun sync(j: List<String>) {
        val others = j.filter { it != meUid }
        if (others.isNotEmpty()) {
            sawOthers = true
            status = if (connected.isEmpty()) "Connecting..." else "Connected"
        }
        for (u in others) {
            val existed = links.containsKey(u)
            val l = link(u)
            if (!existed && meUid < u) offer(l)
        }
        for (u in links.keys.toList()) {
            if (u !in j) drop(u)
        }
        if (sawOthers && others.isEmpty()) finish(true)
    }

    private fun link(u: String): Link = links.getOrPut(u) {
        val l = Link(u)
        val obs = object : PeerConnection.Observer {
            override fun onSignalingChange(p0: PeerConnection.SignalingState?) {}
            override fun onIceConnectionChange(p0: PeerConnection.IceConnectionState?) {}
            override fun onIceConnectionReceivingChange(p0: Boolean) {}
            override fun onIceGatheringChange(p0: PeerConnection.IceGatheringState?) {}
            override fun onIceCandidate(c: IceCandidate?) {
                if (c == null) return
                val o = JSONObject()
                o.put("mid", c.sdpMid)
                o.put("idx", c.sdpMLineIndex)
                o.put("cand", c.sdp)
                send(u, "ice", o.toString())
            }
            override fun onIceCandidatesRemoved(p0: Array<out IceCandidate>?) {}
            override fun onAddStream(p0: org.webrtc.MediaStream?) {}
            override fun onRemoveStream(p0: org.webrtc.MediaStream?) {}
            override fun onDataChannel(p0: org.webrtc.DataChannel?) {}
            override fun onRenegotiationNeeded() {}
            override fun onConnectionChange(s: PeerConnection.PeerConnectionState?) {
                when (s) {
                    PeerConnection.PeerConnectionState.CONNECTED -> {
                        connected = connected + u
                        status = "Connected"
                    }
                    PeerConnection.PeerConnectionState.FAILED,
                    PeerConnection.PeerConnectionState.DISCONNECTED,
                    PeerConnection.PeerConnectionState.CLOSED -> connected = connected - u
                    else -> {}
                }
            }
        }
        val cfg = PeerConnection.RTCConfiguration(iceServers)
        cfg.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        val pc = factory!!.createPeerConnection(cfg, obs)
        l.pc = pc
        pc?.addTrack(track, listOf("hg"))
        l
    }

    private fun drop(u: String) {
        links.remove(u)?.let {
            it.pc?.close()
            it.pc?.dispose()
        }
        connected = connected - u
    }

    private fun send(to: String, kind: String, payload: String) {
        val id = active?.id ?: return
        callRef(id).collection("signals").add(
            mapOf("from" to meUid, "to" to to, "kind" to kind, "payload" to payload)
        )
    }

    private fun offer(l: Link) {
        if (l.offered) return
        l.offered = true
        val pc = l.pc ?: return
        pc.createOffer(object : Sdp() {
            override fun onCreateSuccess(p0: SessionDescription?) {
                if (p0 == null) return
                pc.setLocalDescription(Sdp(), p0)
                send(l.uid, "offer", p0.description)
            }
        }, MediaConstraints())
    }

    private fun drain(l: Link) {
        val pc = l.pc ?: return
        l.pending.forEach { pc.addIceCandidate(it) }
        l.pending.clear()
    }

    private fun handleSignal(doc: DocumentSnapshot) {
        val from = doc.getString("from") ?: return
        val kind = doc.getString("kind") ?: return
        val payload = doc.getString("payload") ?: return
        doc.reference.delete()
        if (active == null) return
        val l = link(from)
        val pc = l.pc ?: return
        when (kind) {
            "offer" -> pc.setRemoteDescription(object : Sdp() {
                override fun onSetSuccess() {
                    l.remoteSet = true
                    drain(l)
                    pc.createAnswer(object : Sdp() {
                        override fun onCreateSuccess(p0: SessionDescription?) {
                            if (p0 == null) return
                            pc.setLocalDescription(Sdp(), p0)
                            send(from, "answer", p0.description)
                        }
                    }, MediaConstraints())
                }
            }, SessionDescription(SessionDescription.Type.OFFER, payload))

            "answer" -> pc.setRemoteDescription(object : Sdp() {
                override fun onSetSuccess() {
                    l.remoteSet = true
                    drain(l)
                }
            }, SessionDescription(SessionDescription.Type.ANSWER, payload))

            "ice" -> {
                val o = JSONObject(payload)
                val c = IceCandidate(o.optString("mid"), o.optInt("idx"), o.optString("cand"))
                if (l.remoteSet) pc.addIceCandidate(c) else l.pending.add(c)
            }
        }
    }

    private fun finish(notifyRemote: Boolean) {
        val a = active ?: return
        ringJob?.cancel()
        callReg?.remove()
        sigReg?.remove()
        callReg = null
        sigReg = null
        for (u in links.keys.toList()) drop(u)
        if (notifyRemote) {
            try {
                if (joined.size <= 1) callRef(a.id).delete()
                else callRef(a.id).update("joined", FieldValue.arrayRemove(meUid))
            } catch (_: Exception) {
            }
        }
        try {
            val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.isSpeakerphoneOn = false
            am.mode = AudioManager.MODE_NORMAL
            app.stopService(Intent(app, CallService::class.java))
        } catch (_: Exception) {
        }
        declined.add(a.id)
        active = null
        joined = emptySet()
        connected = emptySet()
        sawOthers = false
    }
}

// ---------- call screens ----------

@Composable
fun CallsTab(uid: String, myName: String, withMic: (() -> Unit) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var friends by remember { mutableStateOf(listOf<Friend>()) }
    var picked by remember { mutableStateOf(setOf<String>()) }
    var err by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(uid) {
        while (true) {
            try {
                friends = loadFriends(uid)
            } catch (e: Exception) {
                err = e.message
            }
            delay(30_000L)
        }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Text(
            "Calls",
            style = MaterialTheme.typography.headlineSmall.copy(brush = brandBrush(), fontWeight = FontWeight.Bold)
        )
        Spacer(Modifier.height(4.dp))
        Text(
            "Pick up to 4 friends. Calls are limited to 5 people (you + 4) so they stay smooth.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            "🔇 Background noise suppression is on.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.secondary
        )
        err?.let {
            Spacer(Modifier.height(6.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }
        Spacer(Modifier.height(8.dp))
        if (friends.isEmpty()) {
            Text(
                "Add friends in the Friends tab first.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(1f)
            )
        } else {
            LazyColumn(Modifier.weight(1f)) {
                items(friends, key = { it.uid }) { f ->
                    val dot = when {
                        !f.online -> Color(0xFF6B7280)
                        f.status == "busy" -> Color(0xFFEF4444)
                        else -> Color(0xFF22C55E)
                    }
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable {
                                picked = when {
                                    f.uid in picked -> picked - f.uid
                                    picked.size < 4 -> picked + f.uid
                                    else -> { err = "Maximum 4 friends (5 people total)"; picked }
                                }
                            }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Avatar(f.name, dot = dot)
                        Spacer(Modifier.width(12.dp))
                        Text("@${f.name}", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                        Checkbox(checked = f.uid in picked, onCheckedChange = null)
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Button(
            enabled = picked.isNotEmpty() && CallManager.active == null,
            modifier = Modifier.fillMaxWidth().height(50.dp),
            shape = RoundedCornerShape(14.dp),
            onClick = {
                err = null
                withMic {
                    scope.launch {
                        val targets = friends.filter { it.uid in picked }.map { it.uid to it.name }
                        val e = CallManager.start(ctx, uid, myName, targets)
                        if (e != null) err = e else picked = emptySet()
                    }
                }
            }
        ) {
            Text(
                if (picked.size <= 1) "📞 Start call" else "📞 Start group call (${picked.size + 1} people)",
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun CallScreen(onMinimize: () -> Unit) {
    val a = CallManager.active ?: return
    BackHandler(onBack = onMinimize)
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(16.dp))
            Text(
                if (a.members.size > 2) "Group call" else "Voice call",
                style = MaterialTheme.typography.headlineMedium.copy(brush = brandBrush(), fontWeight = FontWeight.Bold)
            )
            Text(CallManager.status, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(24.dp))
            LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                items(a.members, key = { it }) { u ->
                    val name = a.names[u] ?: "user"
                    val mine = u == CallManager.meUid
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Avatar(name, size = 52.dp)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(if (mine) "@$name (you)" else "@$name", fontWeight = FontWeight.Bold)
                            Text(
                                when {
                                    mine -> if (CallManager.muted) "Muted" else "Speaking"
                                    u in CallManager.connected -> "Connected"
                                    u in CallManager.joined -> "Connecting..."
                                    else -> "Ringing..."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = if (u in CallManager.connected) Color(0xFF22C55E)
                                else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
            Text(
                "🔇 Noise suppression on",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.secondary
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Pill(if (CallManager.muted) "Unmute" else "Mute", CallManager.muted) { CallManager.toggleMute() }
                Pill(if (CallManager.speaker) "Speaker on" else "Speaker off", CallManager.speaker) { CallManager.toggleSpeaker() }
            }
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = { CallManager.hangup() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("End call", fontWeight = FontWeight.Bold, color = Color.White) }
            TextButton(onClick = onMinimize) { Text("Minimize (stay in call)") }
        }
    }
}

@Composable
fun CallBanner(onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth()
            .background(Color(0xFF16A34A))
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("📞 In a call - tap to return", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}

@Composable
fun IncomingCallDialog(inc: IncomingCall, uid: String, withMic: (() -> Unit) -> Unit) {
    val ctx = LocalContext.current
    LaunchedEffect(inc.id) {
        delay(45_000L)
        if (CallManager.incoming?.id == inc.id) CallManager.incoming = null
    }
    AlertDialog(
        onDismissRequest = { CallManager.decline(inc.id) },
        title = { Text("📞 Incoming call") },
        text = {
            Text(
                if (inc.members.size > 2) "@${inc.hostName} is starting a group call (${inc.members.size} people)."
                else "@${inc.hostName} is calling you."
            )
        },
        confirmButton = {
            TextButton(onClick = {
                withMic { CallManager.begin(ctx, inc.id, uid, inc.members, inc.names) }
            }) { Text("Accept") }
        },
        dismissButton = { TextButton(onClick = { CallManager.decline(inc.id) }) { Text("Decline") } }
    )
}

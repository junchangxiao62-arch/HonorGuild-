package com.jun.honorguild

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.PublicKey
import java.security.SecureRandom
import java.security.spec.ECGenParameterSpec
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/** End-to-end encryption: ECDH (P-256) -> HKDF-SHA256 -> AES-256-GCM. */
object Crypto {
    private val rng = SecureRandom()

    fun newKeyPair(): KeyPair {
        val g = KeyPairGenerator.getInstance("EC")
        g.initialize(ECGenParameterSpec("secp256r1"))
        return g.generateKeyPair()
    }

    fun b64(b: ByteArray): String = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun unb64(s: String): ByteArray = Base64.decode(s, Base64.NO_WRAP)

    fun publicFrom(s: String): PublicKey =
        KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(unb64(s)))

    fun privateFrom(s: String): PrivateKey =
        KeyFactory.getInstance("EC").generatePrivate(PKCS8EncodedKeySpec(unb64(s)))

    private fun hmac(key: ByteArray, data: ByteArray): ByteArray {
        val m = Mac.getInstance("HmacSHA256")
        m.init(SecretKeySpec(key, "HmacSHA256"))
        return m.doFinal(data)
    }

    fun sharedKey(myPrivate: PrivateKey, theirPublic: PublicKey): SecretKeySpec {
        val ka = KeyAgreement.getInstance("ECDH")
        ka.init(myPrivate)
        ka.doPhase(theirPublic, true)
        val secret = ka.generateSecret()
        val prk = hmac(ByteArray(32), secret)
        val okm = hmac(prk, "HonorGuild-chat-v1".toByteArray() + byteArrayOf(1))
        return SecretKeySpec(okm, "AES")
    }

    fun encrypt(key: SecretKeySpec, text: String): String {
        val iv = ByteArray(12)
        rng.nextBytes(iv)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        return b64(iv + c.doFinal(text.toByteArray(Charsets.UTF_8)))
    }

    fun decrypt(key: SecretKeySpec, data: String): String {
        val raw = unb64(data)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, raw.copyOfRange(0, 12)))
        return String(c.doFinal(raw, 12, raw.size - 12), Charsets.UTF_8)
    }

    fun encryptBytes(key: SecretKeySpec, data: ByteArray): String {
        val iv = ByteArray(12)
        rng.nextBytes(iv)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        return b64(iv + c.doFinal(data))
    }

    fun decryptBytes(key: SecretKeySpec, data: String): ByteArray {
        val raw = unb64(data)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, raw.copyOfRange(0, 12)))
        return c.doFinal(raw, 12, raw.size - 12)
    }

    /** Both people see the same number. If it matches, nobody swapped the keys. */
    fun safetyNumber(pubA: String, pubB: String): String {
        val sorted = listOf(pubA, pubB).sorted()
        val h = MessageDigest.getInstance("SHA-256").digest((sorted[0] + sorted[1]).toByteArray())
        return h.take(15).joinToString("") { "%02x".format(it) }.chunked(5).joinToString(" ")
    }
}

/** Private key never leaves the phone; it is stored in encrypted storage. */
object Keys {
    private fun prefs(ctx: Context): SharedPreferences {
        val mk = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        return EncryptedSharedPreferences.create(
            ctx, "hg_secure", mk,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun myPrivate(ctx: Context, uid: String): String? = prefs(ctx).getString("priv_$uid", null)
    fun myPublic(ctx: Context, uid: String): String? = prefs(ctx).getString("pub_$uid", null)

    /** Creates a fresh key pair for this account on this phone, returns the public key. */
    fun createFor(ctx: Context, uid: String): String {
        val kp = Crypto.newKeyPair()
        val pub = Crypto.b64(kp.public.encoded)
        prefs(ctx).edit()
            .putString("priv_$uid", Crypto.b64(kp.private.encoded))
            .putString("pub_$uid", pub)
            .commit()
        return pub
    }

    fun clearFor(ctx: Context, uid: String) {
        prefs(ctx).edit().remove("priv_$uid").remove("pub_$uid").commit()
    }

    fun pinned(ctx: Context, uid: String, peer: String): String? =
        prefs(ctx).getString("pin_${uid}_$peer", null)

    fun pin(ctx: Context, uid: String, peer: String, pub: String) {
        prefs(ctx).edit().putString("pin_${uid}_$peer", pub).commit()
    }
}

package com.jun.honorguild

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

object Prefs {
    private fun p(ctx: Context) = ctx.getSharedPreferences("hg_prefs", Context.MODE_PRIVATE)
    fun alerts(ctx: Context): Boolean = p(ctx).getBoolean("alerts", false)
    fun setAlerts(ctx: Context, v: Boolean) {
        p(ctx).edit().putBoolean("alerts", v).apply()
    }
}

object AppState {
    @Volatile var visible: Boolean = false
    @Volatile var openChat: String? = null
}

object Notifs {
    const val CH_SERVICE = "service"
    const val CH_MSG = "messages"
    const val CH_FRIENDS = "friends"
    const val CH_CALL = "calls"
    const val CH_ACTIVE_CALL = "activecall"

    fun init(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_SERVICE, "Background connection", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_MSG, "Messages", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_FRIENDS, "Friends online", NotificationManager.IMPORTANCE_DEFAULT))
        nm.createNotificationChannel(NotificationChannel(CH_CALL, "Incoming calls", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_ACTIVE_CALL, "Active call", NotificationManager.IMPORTANCE_LOW))
    }

    fun open(ctx: Context): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(ctx, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun post(ctx: Context, id: Int, channel: String, title: String, text: String) {
        try {
            val n = NotificationCompat.Builder(ctx, channel)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(text)
                .setAutoCancel(true)
                .setContentIntent(open(ctx))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .build()
            NotificationManagerCompat.from(ctx).notify(id, n)
        } catch (_: SecurityException) {
        }
    }
}

/** Free alternative to push notifications: a small foreground service that listens to Firestore. */
class NotifyService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val regs = mutableListOf<ListenerRegistration>()
    private val userRegs = HashMap<String, ListenerRegistration>()

    private class Seen(var name: String, var last: Long, var status: String, var online: Boolean, var notified: Long)

    private val seen = HashMap<String, Seen>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Notifs.init(this)
        val uid = FirebaseAuth.getInstance().currentUser?.uid
        val n: Notification = NotificationCompat.Builder(this, Notifs.CH_SERVICE)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("HonorGuild")
            .setContentText("Watching for messages, calls and friends")
            .setOngoing(true)
            .setContentIntent(Notifs.open(this))
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        if (uid == null || !Prefs.alerts(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (regs.isEmpty()) watch(uid)
        return START_STICKY
    }

    override fun onDestroy() {
        regs.forEach { it.remove() }
        regs.clear()
        userRegs.values.forEach { it.remove() }
        userRegs.clear()
        scope.cancel()
        super.onDestroy()
    }

    private fun watch(uid: String) {
        val db = FirebaseFirestore.getInstance()

        // new messages
        var chatsReady = false
        regs.add(
            db.collection("chats").whereArrayContains("participants", uid)
                .addSnapshotListener { snap, _ ->
                    if (snap == null) return@addSnapshotListener
                    if (!chatsReady) { chatsReady = true; return@addSnapshotListener }
                    if (AppState.visible) return@addSnapshotListener
                    for (ch in snap.documentChanges) {
                        val d = ch.document
                        val last = d.getString("lastSender")
                        if (ch.type == DocumentChange.Type.REMOVED || last == null || last == uid) continue
                        val parts = d.get("participants") as? List<*> ?: continue
                        val other = parts.firstOrNull { it != uid } as? String ?: continue
                        val name = ((d.get("names") as? Map<*, *>)?.get(other) as? String) ?: "someone"
                        Notifs.post(this, d.id.hashCode(), Notifs.CH_MSG, "@$name", "New message")
                    }
                }
        )

        // incoming calls
        regs.add(
            db.collection("calls").whereArrayContains("members", uid)
                .addSnapshotListener { snap, _ ->
                    if (snap == null || AppState.visible) return@addSnapshotListener
                    val now = System.currentTimeMillis()
                    for (ch in snap.documentChanges) {
                        if (ch.type != DocumentChange.Type.ADDED) continue
                        val d = ch.document
                        val host = d.getString("host") ?: continue
                        if (host == uid) continue
                        val joined = (d.get("joined") as? List<*>) ?: emptyList<Any>()
                        if (joined.any { it == uid }) continue
                        val created = d.getTimestamp("created", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                            ?.toDate()?.time ?: continue
                        if (now - created > 45_000L) continue
                        val hostName = ((d.get("names") as? Map<*, *>)?.get(host) as? String) ?: "someone"
                        Notifs.post(this, 4242, Notifs.CH_CALL, "Incoming call", "@$hostName is calling you")
                    }
                }
        )

        // friends coming online
        regs.add(
            db.collection("users").document(uid).collection("friends")
                .addSnapshotListener { snap, _ ->
                    if (snap == null) return@addSnapshotListener
                    val ids = snap.documents.map { it.id }.toSet()
                    for (id in ids) {
                        if (userRegs.containsKey(id)) continue
                        userRegs[id] = db.collection("users").document(id)
                            .addSnapshotListener { ud, _ ->
                                if (ud == null || !ud.exists()) return@addSnapshotListener
                                val s = seen.getOrPut(id) { Seen("user", 0L, "online", false, 0L) }
                                s.name = ud.getString("username") ?: s.name
                                s.status = ud.getString("status") ?: "online"
                                s.last = ud.getTimestamp("lastSeen")?.toDate()?.time ?: 0L
                            }
                    }
                    for (id in userRegs.keys.toList()) {
                        if (id !in ids) {
                            userRegs.remove(id)?.remove()
                            seen.remove(id)
                        }
                    }
                }
        )

        scope.launch {
            var first = true
            while (true) {
                delay(if (first) 8_000L else 30_000L)
                val now = System.currentTimeMillis()
                for ((_, s) in seen) {
                    val on = s.last > 0L && now - s.last < 240_000L && s.status != "invisible"
                    if (on && !s.online && !first && !AppState.visible && now - s.notified > 600_000L) {
                        Notifs.post(this@NotifyService, s.name.hashCode(), Notifs.CH_FRIENDS, "@${s.name} is online", "Tap to open HonorGuild")
                        s.notified = now
                    }
                    s.online = on
                }
                first = false
            }
        }
    }

    companion object {
        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, NotifyService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, NotifyService::class.java))
        }
    }
}

/** Keeps the call alive (and the microphone allowed) while you switch to a game. */
class CallService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Notifs.init(this)
        if (intent?.action == "end") {
            CallManager.hangup()
            stopSelf()
            return START_NOT_STICKY
        }
        val endIntent = PendingIntent.getService(
            this, 1, Intent(this, CallService::class.java).setAction("end"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, Notifs.CH_ACTIVE_CALL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("HonorGuild call")
            .setContentText("Voice call in progress")
            .setOngoing(true)
            .setContentIntent(Notifs.open(this))
            .addAction(0, "End call", endIntent)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        else ServiceInfo.FOREGROUND_SERVICE_TYPE_MANIFEST
        ServiceCompat.startForeground(this, 2, n, type)
        return START_NOT_STICKY
    }
}

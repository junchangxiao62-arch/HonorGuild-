package com.jun.honorguild

import android.text.format.DateUtils
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val avatarColors = listOf(
    0xFFE11D48, 0xFF8B5CF6, 0xFF0EA5E9, 0xFF10B981,
    0xFFF59E0B, 0xFFEC4899, 0xFF6366F1, 0xFF14B8A6
).map { Color(it) }

@Composable
fun brandBrush(): Brush = Brush.horizontalGradient(
    listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.secondary)
)

@Composable
fun Avatar(name: String, size: Dp = 46.dp, online: Boolean? = null) {
    val c = avatarColors[(name.hashCode() and 0x7fffffff) % avatarColors.size]
    Box(Modifier.size(size)) {
        Box(
            Modifier.size(size).background(c, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                name.firstOrNull()?.uppercase() ?: "?",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = (size.value * 0.42f).sp
            )
        }
        if (online != null) {
            Box(
                Modifier.size(size * 0.30f)
                    .align(Alignment.BottomEnd)
                    .background(MaterialTheme.colorScheme.background, CircleShape)
                    .padding(2.dp)
                    .background(if (online) Color(0xFF22C55E) else Color(0xFF6B7280), CircleShape)
            )
        }
    }
}

@Composable
fun Logo(size: Dp) {
    Box(
        Modifier.size(size)
            .clip(RoundedCornerShape(size * 0.22f))
            .background(Color(0xFF140A1F)),
        contentAlignment = Alignment.Center
    ) {
        Image(painterResource(R.drawable.ic_fg), contentDescription = null, modifier = Modifier.size(size))
    }
}

fun fmtClock(ms: Long): String =
    SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(ms))

fun fmtListTime(ms: Long): String {
    if (ms <= 0L) return ""
    return if (DateUtils.isToday(ms)) fmtClock(ms)
    else SimpleDateFormat("MMM d", Locale.getDefault()).format(Date(ms))
}
